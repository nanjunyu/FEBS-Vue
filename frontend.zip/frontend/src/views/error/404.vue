<template>
  <exception-page type="404" />
</template>

<script>
import ExceptionPage from '~/exception/ExceptionPage'
export default {
  components: {ExceptionPage}
}
</script>

<style scoped>

</style>
